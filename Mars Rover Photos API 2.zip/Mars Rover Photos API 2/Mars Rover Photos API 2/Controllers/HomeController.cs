﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Mars_Rover_Photos_API_2.Models;
using System.Web;
using System.Net;
using System.IO;
using System.Globalization;
using Microsoft.Extensions.Options;

namespace Mars_Rover_Photos_API_2.Controllers
{
	public class HomeController : Controller
	{
		private AppSettings AppSettings { get; set; }
		public HomeController(IOptions<AppSettings> settings)
		{
			AppSettings = settings.Value;
		}
		public IActionResult Index()
		{
			return View();
		}
				
		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}

		[HttpPost]
		public string DownLoadImage(string imageUrl)
		{
			int index = imageUrl.LastIndexOf("/");
			string remoteUri = imageUrl.Substring(0,index+1);
			string fileName = imageUrl.Substring(index + 1);
			DownloadImageFromUrl(remoteUri, fileName);

			return "Download Image successfully";
		}

		[HttpGet]
		public JsonResult DownLoadImageByDate()
		{
			var rs = new List<string>();
			string fileName = "date.txt";
			string dirFileName = Path.Combine(AppSettings.DirectoryFile, fileName); 

			string[] lines = System.IO.File.ReadAllLines(dirFileName);

			foreach(var line in lines)
			{				
				DateTime date = Convert.ToDateTime(line);
				
				string fm = string.Format("{0:yyyy-MM-dd}", date);
				rs.Add(fm);
			}
			
			return Json(rs);
		}

   		public void DownloadImageFromUrl(string remoteUri, string fileName)
		{
			try
			{
				string myStringWebResource = null;
				
				WebClient myWebClient = new WebClient();
				
				myStringWebResource = remoteUri + fileName;

				string dirFileName = Path.Combine(AppSettings.DirectoryFile, fileName);

				myWebClient.DownloadFile(myStringWebResource, dirFileName);
				
			}
			catch (Exception ex)
			{
				throw;
			}			
		}
	}
}
