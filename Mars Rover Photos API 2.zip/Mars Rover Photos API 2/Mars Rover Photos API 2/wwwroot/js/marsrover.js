﻿var api_key = "OLP5w2hlUFI70sEM0QUk7LC0JRkxdfA6nJzcyQLo";
var url = "https://api.nasa.gov/planetary/apod?api_key=" + api_key;


$("#loadImageByDate").click(function () {
	var date = $("#date").val();
	$("#divloadbydate").css("display", "block");
	
	$.ajax({
		url: url + "&date=" + date,
		success: handleResult
	});

	function handleResult(result) {		
		$("#spaceimage").attr("src", result.url);		
	}
});

$("#btnDownLoad").click(function () {
	var urlImg = $("#spaceimage").attr("src");
	downloadPhoto(urlImg);
});

$("#divloadImgByDateFromFile").on('click', '#btnDownLoad1', function () {
	
	var urlImg = $("#spaceimage1").attr("src");
	downloadPhoto(urlImg);		
});

$("#divloadImgByDateFromFile").on('click', '#btnDownLoad2', function () {
	
	var urlImg = $("#spaceimage2").attr("src");
	downloadPhoto(urlImg);	
});

$("#divloadImgByDateFromFile").on('click', '#btnDownLoad3', function () {
	
	var urlImg = $("#spaceimage3").attr("src");
	downloadPhoto(urlImg);
});

$("#divloadImgByDateFromFile").on('click', '#btnDownLoad4', function () {
	
	var urlImg = $("#spaceimage4").attr("src");
	downloadPhoto(urlImg);
});


function downloadPhoto(urlImg) {
	$.ajax({
		type: "POST",
		contentType: "application/json; charset=utf-8",
		url: "Home/DownLoadImage?imageUrl=" + urlImg,
		success: function (result, status, xhr) {
			alert(result);
		},
		error: function (xhr, status, error) {
			alert(error);
		}
	});		
}


$("#loadImageByDateInFile").click(function () {
	$("#divloadfile").css("display", "block");
	$("#headerphoto").css("display", "block");
	$("#divloadImgByDateFromFile").css("display", "block");
	$("#divloadImgByDateFromFile").empty();
	$.ajax({
		type: "GET",
		contentType: "application/json; charset=utf-8",
		url: "Home/DownLoadImageByDate",
		success: function (result, status, xhr) {
			processDate(result);
		},
		error: function (xhr, status, error) {
			alert(error);
		}
	});

	function processDate(result) {		
		var arr = String(result).split(",");
		arr.forEach((item, index) => DisplayPhoto(item, index + 1));	
	}

	function DisplayImage(item, index) {		
		$.ajax({
			url: url + "&date=" + item,
			success: function (result, status, xhr) {
				handleResult2(result);
			},
			error: function (xhr, status, error) {
				alert(error);
			}
		});

		function handleResult2(result) {
			
			$("#spaceimage" + index).attr("src", result.url);


		}
	}

	function DisplayPhoto(item, index) {
		
		$.ajax({
			url: url + "&date=" + item,
			success: function (result, status, xhr) {
				creatListItem(result);
			},
			error: function (xhr, status, error) {
				alert(error);
			}
		});

		function creatListItem(result) {
			id = "spaceimage" + index;

			divTagOpen = "<div class='col-lg-3 col-md-4 col-6'>";
			divTagClosed = "</div>";
			aTagOpen = "<a href='#' class='d-block mb-4 h-100'>";
			aTagClosed = "</a>";
			imgTag = "<img class='img-fluid img-thumbnail' src='" + result.url + "' id='" + id + "'>";
			btnId = "btnDownLoad" + index;

			var btnTag = "<button id='" + btnId + "' class='btn bg-info'><i class='fa fa-download'></i></button>";

			var src = divTagOpen + aTagOpen + imgTag + btnTag + aTagClosed + divTagClosed;
			
			$("#divloadImgByDateFromFile").append(src);

		}
	}
});