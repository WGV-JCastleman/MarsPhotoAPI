﻿using System;
using System.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System.IO;


namespace UnitTesting_Mars_Rover
{
	/// <summary>
	/// This test will use test in Chrome browser
	/// </summary>
	[TestClass]
	public class Mars_Rover_Unit_Test
	{
		private string url;
		private int delaytime;
		private IWebDriver webDriver;
		private string directory;

		[TestInitialize]
		public void TestInitialize()
		{
			url = ConfigurationManager.AppSettings["UrlMarsRoverPhoto"];
			delaytime = 15;
			webDriver = new OpenQA.Selenium.Chrome.ChromeDriver();
			directory = ConfigurationManager.AppSettings["DirectoryFile"];		

		}

		[TestCleanup]
		public void TestCleanup()
		{
			Cleanup();
		}

		/// <summary>
		/// <name>Mars_Rover_DisplayImage_By_InputDate_Test</name>
		/// <shortDescription>
		/// Test the API shows image by input date. The test will automatically download the image into the directory C:\temp
		/// </shortDescription>
		/// </summary>
		/// <step key="1">
		/// <description>Enter date 2020-01-15 into the texbox, clicks the button "Load Image"</description>
		/// <inputs></inputs>
		/// <expectedOutput>The image display on browser</expectedOutput>
		/// </step>
		/// <step key="2">
		/// <description>Clicks the icon download</description>
		/// <inputs></inputs>
		/// <expectedOutput>the image will exist in the rectory C:\temp</expectedOutput>
		/// </step>
		[TestMethod]
		public void Mars_Rover_DisplayImage_By_InputDate_Test()
		{
			try
			{		

				GoToPage();

				DownloadImageByGivenDate();


			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		/// <summary>
		/// <name>Mars_Rover_DisplayImage_By_Date_FromFile_Test</name>
		/// <shortDescription>
		/// Test the API shows 4 images by reading date from a date.txt file. The test will automatically download the images into the directory C:\temp
		/// </shortDescription>
		/// </summary>
		/// <step key="1">
		/// <description>Clicks the button "Load Image with date from a file"</description>
		/// <inputs></inputs>
		/// <expectedOutput>4 images display on browser</expectedOutput>
		/// </step>
		/// <step key="2">
		/// <description>Clicks the icon download</description>
		/// <inputs></inputs>
		/// <expectedOutput>4 images will exist in the rectory C:\temp</expectedOutput>
		/// </step>
		[TestMethod]
		public void Mars_Rover_DisplayImage_By_Date_FromFile_Test()
		{
			try
			{

				GoToPage();

				DownloadImageByDateFromFile();


			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		private void GoToPage()
		{
			webDriver.Navigate().GoToUrl(url);
		}

		private void DownloadImageByDateFromFile()
		{
			// click loadImageByDateInFile
			WebDriverWait wait = new WebDriverWait(webDriver, System.TimeSpan.FromSeconds(delaytime));
			wait.Until(driver => driver.FindElement(By.Id("loadImageByDateInFile")));
			IWebElement elementBtn = webDriver.FindElement(By.Id("loadImageByDateInFile"));

			elementBtn.Click();

			// Download image to a folder
			try
			{				
				for (int i = 1; i <= 4; i++)
				{
					wait = new WebDriverWait(webDriver, System.TimeSpan.FromSeconds(delaytime));
					wait.Until(driver => driver.FindElement(By.Id($"btnDownLoad{i}")));
					
					IWebElement elementBtnDownLoad = webDriver.FindElement(By.Id($"btnDownLoad{i}"));
					elementBtnDownLoad.Click();
					wait.Until(ExpectedConditions.AlertIsPresent());
					var alert = webDriver.SwitchTo().Alert();
					alert.Accept();					
				}
			}
			catch(Exception ex)
			{
				throw;
			}		

		}

		private void DownloadImageByGivenDate()
		{
			DateTime date = new DateTime(2020, 1, 15);

			WebDriverWait wait = new WebDriverWait(webDriver, System.TimeSpan.FromSeconds(delaytime));
			wait.Until(driver => driver.FindElement(By.Id("date")));
			IWebElement elementDate = webDriver.FindElement(By.Id("date"));
			elementDate.SendKeys(string.Format("{0:yyyy-MM-dd}", date));

			// click loadImageByDate
			wait = new WebDriverWait(webDriver, System.TimeSpan.FromSeconds(delaytime));
			wait.Until(driver => driver.FindElement(By.Id("loadImageByDate")));
			IWebElement elementBtn = webDriver.FindElement(By.Id("loadImageByDate"));

			elementBtn.Click();

			// Download image to a folder
			try
			{
				wait = new WebDriverWait(webDriver, System.TimeSpan.FromSeconds(delaytime));
				wait.Until(driver => driver.FindElement(By.Id("btnDownLoad")));
				IWebElement elementBtnDownLoad = webDriver.FindElement(By.Id("btnDownLoad"));
				elementBtnDownLoad.Click();

				wait.Until(ExpectedConditions.AlertIsPresent());
				var alert = webDriver.SwitchTo().Alert();
				alert.Accept();
			}
			catch(Exception e)
			{
				throw;
			}

		}

		private void Cleanup()
		{
			webDriver.Dispose();
		}
	}
}
